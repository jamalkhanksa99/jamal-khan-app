package com.das360.jamalkhanah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
